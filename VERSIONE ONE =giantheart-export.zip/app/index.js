import clock from "clock";
import document from "document";
import { preferences } from "user-settings";
import * as util from "../common/utils";
import { HeartRateSensor } from "heart-rate";

//---------------------------------------------------------------
// 
//---------------------------------------------------------------
import { me as appbit } from "appbit";
import { today } from "user-activity";



//---------------------------------------------------------------
// clock
//---------------------------------------------------------------


// Update the clock every minute
clock.granularity = "minutes";

// Get a handle on the <text> element
const myLabel = document.getElementById("myLabel");

// Update the <text> element every tick with the current time
clock.ontick = (evt) => {
  let today = evt.date;
  let hours = today.getHours();
  if (preferences.clockDisplay === "12h") {
    // 12h format
    hours = hours % 12 || 12;
  } else {
    // 24h format
    hours = util.zeroPad(hours);
  }
  let mins = util.zeroPad(today.getMinutes());
  myLabel.text = `${hours}:${mins}`;
}

//---------------------------------------------------------------
// heart rate
//---------------------------------------------------------------
const heartrate = document.getElementById("heartrate");
import { HeartRateSensor } from "heart-rate";

if (HeartRateSensor) {
   console.log("This device has a HeartRateSensor!");
   const hrm = new HeartRateSensor();
   hrm.addEventListener("reading", () => {
      heartrate.text=hrm.heartRate;
      print(hrm.heartRate);
     
     //console.log(hrm.timestamp);
   });
   hrm.start();
} else {
   console.log("This device does NOT have a HeartRateSensor!");
}

//---------------------------------------------------------------
//
//---------------------------------------------------------------


var counter=0;

function print(x){

      if(x>=90){
        counter++
      }
      history.text= Math.floor(counter/60)+':'+(counter%60);
}


//---------------------------------------------------------------
//
//---------------------------------------------------------------
function getAvg(grades) {
  const total = grades.reduce((acc, c) => acc + c, 0);
  return (total / grades.length).toFixed(1);
}

//---------------------------------------------------------------
//
//---------------------------------------------------------------

const history = document.getElementById("history");
import { minuteHistory } from "user-activity";



  function getHeartRate(){
      if (appbit.permissions.granted("access_activity") ) {

        var x= JSON.stringify(minuteHistory.query()[5]);
        history.text=x.averageHeartRate;
        console.log('-->'+x.averageHeartRate);

      }
  }

