import clock from "clock";
import document from "document";
import { preferences } from "user-settings";
import * as util from "../common/utils";
import { HeartRateSensor } from "heart-rate";

//---------------------------------------------------------------
// 
//---------------------------------------------------------------
import { me as appbit } from "appbit";
import { today } from "user-activity";


//---------------------------------------------------------------
// 
//---------------------------------------------------------------
const marc = document.getElementById("marc");


//---------------------------------------------------------------
//
//---------------------------------------------------------------
/*

import { minuteHistory } from "user-activity";

if (appbit.permissions.granted("access_activity") ) {
  
   var x= JSON.stringify(minuteHistory.query()[0]);
   marc.text=x;
    console.log('-->'+x);
  
}
*/

import { HeartRateSensor } from "heart-rate";

if (HeartRateSensor) {
   console.log("This device has a HeartRateSensor!");
   const hrm = new HeartRateSensor();
   hrm.addEventListener("reading", () => {
      marc.text=hrm.heartRate;
   });
   hrm.start();
} else {
   console.log("This device does NOT have a HeartRateSensor!");
}


