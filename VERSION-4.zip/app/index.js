import clock from "clock";
import document from "document";
import { preferences } from "user-settings";
import * as util from "../common/utils";
import { HeartRateSensor } from "heart-rate";

//---------------------------------------------------------------
// 
//---------------------------------------------------------------
import { me as appbit } from "appbit";
import { today } from "user-activity";



//---------------------------------------------------------------
// clock
//---------------------------------------------------------------


// Update the clock every minute
clock.granularity = "seconds";
var old_date;
// Get a handle on the <text> element
const myLabel = document.getElementById("clock");

// Update the <text> element every tick with the current time
clock.ontick = (evt) => {
  let today = evt.date;
  
  var parsed=(today.toString().match(/[\w\d]+/g));
  
  //save date so we can reset stats each new day.
  var new_date=(today.toString().match(/\d\d\ /));
  if(new_date === old_date){
    resetStats();   
  }
  old_date=new_date;
  
  let hours = today.getHours();
  if (preferences.clockDisplay === "12h") {
    // 12h format
    hours = hours % 12 || 12;
  } else {
    // 24h format
    hours = util.zeroPad(hours);
  }
  let mins = util.zeroPad(today.getMinutes());
  myLabel.text = `${hours}:${mins}`;
  
  //makes seconds bounce left and right.
  var offset = parsed[6]%2;
  var standard=230;
  document.getElementById('seconds').x=standard+offset*4;
  
  document.getElementById('seconds').text=`${parsed[6]}`;
  document.getElementById('date').text=`${parsed[0]} ${parsed[1]} ${parsed[2]}`;
}
//---------------------------------------------------------------
// reset stats
//---------------------------------------------------------------
function resetStats(){
     counter=0;
     cals=0;
}
//---------------------------------------------------------------
// heart rate
//---------------------------------------------------------------
const heartrate = document.getElementById("heartrate");
import { HeartRateSensor } from "heart-rate";

if (HeartRateSensor) {
   console.log("This device has a HeartRateSensor!");
   const hrm = new HeartRateSensor();
   hrm.addEventListener("reading", () => {
      var pad='';
      if(hrm.heartRate<100){
        pad='0';
      }
      heartrate.text=pad+hrm.heartRate;
      print(hrm.heartRate);
     
     //console.log(hrm.timestamp);
   });
   hrm.start();
} else {
   console.log("This device does NOT have a HeartRateSensor!");
}


//---------------------------------------------------------------
//  calculate calories cost of a heartbeat
//---------------------------------------------------------------
function getCost(x){
  x= parseInt(x);
  var base_rate= getBaseRate(x);

  var cost_per_x = base_rate*x;
  return cost_per_x;
}


//---------------------------------------------------------------
//  get base rate
//---------------------------------------------------------------
var Heart=[ 80,  90,  96,100, 103, 113,116,119, 147                        ];
var Cost= [1.5, 1.6, 4.9,5.4, 6.7, 7.4,8.2,10.4, 12.4                      ];
function getBaseRate(x){
    var base_rate= 1.6/93;
  
    var copy = Heart.slice();
    copy.push(x);
    copy.sort((a,b)=>a-b);
    var index=copy.indexOf(x);
    if(index>0){
      base_rate=Cost[index-1]/Heart[index-1];
    }else{
      base_rate=Cost[0]/Heart[0];
    }
  
    return base_rate;
}

//---------------------------------------------------------------
//  Print the hearate info
//---------------------------------------------------------------


var counter=0;
var cals=0;
var MAX_RATE=14;
 var SCREEN_WIDTH=299;
function print(x){
      var GOAL=600;
      var total_minutes=120;
       
      var rate_per_minute = getCost(x);
  
      document.getElementById('points').text=rate_per_minute.toFixed(1);
  
      
  
      if(x>=90){
        counter++
        
         
        cals+=getCost(x)/60;
        
      }
      
      // active minutes
      var minutes= Math.floor(counter/60);
      var seconds= (counter%60);
      var hours=Math.floor(counter/60/60); 
      
      var normalRemaining_print=(total_minutes-minutes);
      if(normalRemaining_print <=0){
         normalRemaining_print=' ';
      }
      document.getElementById("normalTime").text=minutes;
      document.getElementById("normalTimeRemaining").text=normalRemaining_print;
      document.getElementById('normalThinBar').width=(seconds/60)*SCREEN_WIDTH;
  
      // show star for every hour
      var star = '.';
      var stars='';
      for(var i=0;i<hours;i++){
        stars+=star;
      }
    
      document.getElementById('hours').text=stars;
      document.getElementById('cals').text=cals.toFixed(0);
  
      // minutes left
      var points_per_minute=5;
      var calsTime= (cals/points_per_minute);
      var remainder=(total_minutes-(calsTime));
      var  remainder_print=Math.floor(remainder);
      
      var bonus= ((total_minutes-minutes)-remainder).toFixed(2);
      var bonus_print=bonus;
  
      if(remainder <=0 ){
          remainder_print=' ';
          
      }
      
      var pad='✅';
      if(bonus <=0 ){
          
          remainder_print=' ';
          pad='';
      }
  
      //document.getElementById('calsTime').text=calsTime.toFixed(0);
      document.getElementById('calsTimeRemaining').text=remainder_print;
      
      document.getElementById('bonus').text=pad+bonus_print;
      document.getElementById('calsThinBar').width=(calsTime%1)*SCREEN_WIDTH;
  
      // progress bar
     
      
      var percent = cals/GOAL;
      
      document.getElementById('calsBar').width=percent*SCREEN_WIDTH;
  
      if(cals >=GOAL){
         
         document.getElementById('barDone').width=SCREEN_WIDTH;
      }
  
      // display biggest
      var biggest = minutes;
      if(bonus>0 ){ // render which ever is bigger & change the color
          biggest=calsTime;
          document.getElementById('biggest').text=Math.floor(biggest).toFixed(0);
          document.getElementById('biggestPlain').text='';
      }else{
          document.getElementById('biggestPlain').text=Math.floor(biggest).toFixed(0);
         document.getElementById('biggest').text='';
      }
    
      document.getElementById('oz').text=((cals/3500)*16).toFixed(1);
  
      var hours=(biggest/60);
      
      for( var i=0;  i<hours  ;i++){
            document.getElementById('hours').text+='🏁';
      }
  
       
  
}


//---------------------------------------------------------------
//
//---------------------------------------------------------------
function getAvg(grades) {
  const total = grades.reduce((acc, c) => acc + c, 0);
  return (total / grades.length).toFixed(1);
}

//---------------------------------------------------------------
// 
//---------------------------------------------------------------





